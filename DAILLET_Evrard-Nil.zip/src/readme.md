# SELP
------
## Environnement
java version: "1.8.0_191"

OS: Windows 10

## Avancement

- Piste verte: Finie
- Piste bleue: Finie
En cours: amélioration de la gestion des erreurs.

## Gestion des erreurs

En cours d'avancement

## Libertés

