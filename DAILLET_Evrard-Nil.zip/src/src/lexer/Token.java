package lexer;

public interface Token {
    @Override
    public abstract String toString();
}
