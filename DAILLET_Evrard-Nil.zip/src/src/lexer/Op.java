package lexer;

public enum Op implements Token {
    PLUS, MINUS, TIMES, DIVIDE, EQUALS, LESS, HIGH,
}


