package lexer;

public class DEFVAR implements Token {
    // TODO: 07/01/2019 Complete the class 
    public String toString() {
        return "DEFVAR";
    }
}
