package lexer;

public class LPAR implements Token {
    // TODO: 07/01/2019 Complete the class
    public String toString() {
        return "LPAR";
    }
}
